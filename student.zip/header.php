<div style="background:#000;height:80px;opacity:.8;"  class="wrapper">
        <div class="logo">
            <img width="70" src="logo.jpg" alt="">
        </div>
<ul class="nav-area">
<li><a href="#">Home</a></li>
<li><a href="#">About Us</a></li>
<li><a href="#">Cources</a></li>
<li><a href="#">Contact Us</a></li>
<li><a href="students.php">Institute Login</a></li>
</ul>
</div>