<!DOCTYPE html>
<!--Code by Divinector (www.divinectorweb.com)-->
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>How to Create responsive Homepage</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">    
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <header>
    <div class="wrapper">
        <div class="logo">
            <img src="logo.jpg" alt="">
        </div>
<ul class="nav-area">
<li><a href="#">Home</a></li>
<li><a href="#">About Us</a></li>
<li><a href="#">Cources</a></li>
<li><a href="#">Contact Us</a></li>
<li><a href="students.php">Institute Login</a></li>
</ul>
</div>
<div class="welcome-text">
        <h1>
Wealcome To <span>Zeal</span></h1>
<a href="#">Cources</a>
    </div>
</header>

</body>
</html>
