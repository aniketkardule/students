<?php  

$api = "https://studentsappp.herokuapp.com/";
$url = "https://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$uri = explode("?",$url);
$result;
if($url != "https://zealstudentsrecord.000webhostapp.com/students.php"){
     $fetch = file_get_contents($api.'search?'.$uri[1]);

if(strpos($uri[1],"id") !== false){
    $result = json_decode('['.$fetch.']');
}else{
       $result = json_decode($fetch);
}

}else{$result = [];}
    ?>


<html>
				<head>
								<title></title>
								<meta name="viewport" content="width=device-width, initial-scale=1.0">
           <link rel="stylesheet" href="style.css"/>
								<style>
input[type=text], select,input[type=number]{
  width:90%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}
.result{
margin-top:120px;
}
p{
margin:10px;
}
.result a{
  background:green;
  color:#fff;
  padding:10px;
  font-weight:bold;
  text-decoration:none;
  border-radius:4px;

  }
								.fbn{
								    text-align:center;
								    align-items:center;
								    margin:0 auto;
								
								}

								input{
     text-align:center;
								    border:1px solid orange;
								}
	.astd{
	    position:absolute;
	    top:140px;
	    right:40px;
	}
	.fbf{
	    text-align:center;
	}
												.fltr{
																width:100%;
																border-bottom:1px solid grey;
												}
												.sfbf{
																display:flex;
												}
												.sub-fbf{
																width:33.33%;
												}
												
												
												
			ul{
			    list-style:none;
			}	
			.s_lst{
			    margin:0 auto;
			    width:80%;
			}
			.s_info{
			    max-height:200px;
			    display:flex;
          overflow:hidden;
left:0;
          -webkit-transition: 0.6s; -moz-transition: 0.6s; -o-transition: 0.6s; transition: 0.6s;
			    position:relative;
			    border-bottom:1px solid #000; 
			}	
			.s_info .u_img{
			    width:100px;
			    height:100px;
			    margin-top:50px;
			    border:1.37px solid #000;
			}
			.s_info .u_img img{
			    max-width:91%;
			    display:block;
			    margin:auto;
			}
			.s_info .u_dtl{
			   margin:0 120px;
height:100%;
         width:300px;
			}
.s_info .u_dtl p{
padding:0;
}
			.name{
			    font-size:18px;
			}
			.update{
			    position:absolute;
			    top:40%;
			    right:20%;
			}
			#delete{
			    position:absolute;
         background:maroon;
			    top:40%;
			    right:10%;
			}
#filter{
    margin-bottom:30px;
   }
								</style>
				</head>
				<body>
        <?php include "header.php";    ?>
								<div class="result">
												<div class="fltr">
																<div class="fbn">
																    
																<p>Find Student By Roll No:</p>
																<input type="number" id="input">
																<a id="id-search" href="#">Search</a>
																<p>OR</p>
																<p>Find Student By Name:</p>
																<input type="text" id="input1">
																<a href="#" id="input-search">Search</a>
																						
																    <a class="astd" href="add-student.php">Add Student</a><br>

															
																</div>
																
															
																<div class="fbf">
																    <p>OR</p>
																		  <p>Find By Filter:</p>
																				<div class="sfbf">
																				<div class="sub-fbf">
																								<p>Select Class:</p>
																								<select id="class">
			<option>ALL</option>																									<option>FE</option>
																												<option>SE</option>
																												<option>TE</option>
																												<option>BE</option>
																								</select>
																				</div>
																				<div class="sub-fbf">
																								<p>Select Branch :</p>
																								<select id="branch">
				<option>ALL</option>																								<option>Computer</option>
																												<option>IT</option>
																												<option>Mechanical</option>
																												<option>Civil</option>
																												<option>AI</option>
																												<option>E & TC</option>
																								</select>
																				</div>
																		
																				<div class="sub-fbf">
																								<p>Select Gender:</p>
																								<select id="gen">
																								    <option>ALL</option>
																												<option>M</option>
																												<option>F</option>
																								</select>
																				</div>
																				</div>
																		      <p id="filter" style="margin-top:30px"><a href="#">Find Students</a></p>
					</div>		
					
			     </div>
					
												
												<div class="rslt">
												    <p>Top results ></p>
																<ul class="s_lst">
    <?php     for($i=0; $i<sizeof($result);$i++){    ?>
																    <li class="s_info">
																    <div class="u_img">
																        <img src="userimg.png" />
																    </div>
																    <div class="u_dtl">
					<p class="name">Name:<?= $result[$i]->name;   ?></p>	
					<p class="r_no">Roll no:<?= $result[$i]->_id;   ?></p>
<p class="branch">Date Of Birth:<?= $result[$i]->dob;   ?></p>
					<p class="class">Class: <?= $result[$i]->class;   ?></p>
					<p class="branch">Branch:<?= $result[$i]->branch;   ?></p>
					<p class="gen">Gender:<?= $result[$i]->gen;   ?></p>
																        </div>
																        <a href="update-student.php?id=<?=  $result[$i]->_id  ?>"	class="update">Update</a>
					<a href="#" onclick="del(this,<?=  $result[$i]->_id;   ?>)" id="delete"	>Delete</a>										    </li>
                                  <?php      }      ?>
																</ul>
												</div>
								</div>
								<script>
								    //Delete Function
								function del(e, i){
								    e.parentNode.style.maxHeight = "0px";
								    
								    fetch('https://studentsappp.herokuapp.com/'+i,{ method:'DELETE' }).then(response=>{ return response.json() }).then(data=>  console.log(data) );
								}
								    
								    //Filter
     document.getElementById('filter').addEventListener('click', function(){
     				
     				const branch = document.getElementById('branch'),
     				clas = document.getElementById('class'),
     		  gen = document.getElementById('gen');
     				var url = "";
     				
     				
     				if(branch.value != "ALL" & clas.value != "ALL" & gen.value != "ALL"){
     								url = "?branch="+branch.value+"&class="+clas.value+"&gen="+gen.value;
     				}else if(branch.value === "ALL" & clas.value === "ALL" & gen.value === "ALL"){
     								url = "?filter=ALL";
     				}else if(branch.value != "ALL" & clas.value === "ALL" & gen.value != "ALL"){
     								url = "?branch="+branch.value+"&gen="+gen.value;
     				}else if(branch.value === "ALL" & clas.value != "ALL" & gen.value != "ALL"){
     								url = "?class="+clas.value+"&gen="+gen.value;
     				}else if(branch.value != "ALL" & clas.value != "ALL" & gen.value === "ALL"){
     								url = "?branch="+branch.value+"&class="+clas.value;
     				}else if(branch.value != "ALL" & clas.value === "ALL" & gen.value === "ALL"){
     								url = "?branch="+branch.value;
     				}else if(branch.value === "ALL" & clas.value != "ALL" & gen.value === "ALL"){
     								url = "?class="+clas.value;
     				}else if(branch.value === "ALL" & clas.value === "ALL" & gen.value != "ALL"){
     								url = "?gen="+gen.value;
     				}
     		
     	if(url !== ""){			
     			document.location.href = "students.php"+url;
     			}
     			
     			
     })
    document.getElementById('input-search').addEventListener('click', function(){

   const value = document.getElementById('input1').value;
        document.location.href = "students.php?name="+value;
});


document.getElementById('id-search').addEventListener('click', function(){

   const value = document.getElementById('input').value;
        document.location.href = "students.php?id="+value;
})
								</script>
				</body>
</html>
